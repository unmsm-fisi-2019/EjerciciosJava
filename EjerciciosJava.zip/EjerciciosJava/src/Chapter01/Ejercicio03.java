/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chapter01;

/**
 *
 * @author Usuario
 */
public class Ejercicio03 {
    public static void main(String[] args) {
        System.out.println("    J    A    V     V    A  ");
        System.out.println("    J   A A    V   V    A A ");
        System.out.println("J   J  AAAAA    V V    AAAAA ");
        System.out.println(" J J  A     A    V    A     A ");

    }
}
