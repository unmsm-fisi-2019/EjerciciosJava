/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chapter01;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class Ejercicio04 {
    public static void main(String[] args) {
        System.out.printf("%-20s%-20s%-20s\n","a","a^2","a^3");
        System.out.printf("%-20s%-20s%-20s\n","1","1 ","1");
        System.out.printf("%-20s%-20s%-20s\n","2","4 ","8");
        System.out.printf("%-20s%-20s%-20s\n","3","9 ","27");
        System.out.printf("%-20s%-20s%-20s\n","4","16","64");
        
    }
}
