/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chapter01;

/**
 *
 * @author Usuario
 */
public class Ejercicio05 {
    public static void main(String[] args) {
        double a=(9.5*4.5-2.5*3)/(45.5-3.5);
        System.out.println(a);
    }
}
